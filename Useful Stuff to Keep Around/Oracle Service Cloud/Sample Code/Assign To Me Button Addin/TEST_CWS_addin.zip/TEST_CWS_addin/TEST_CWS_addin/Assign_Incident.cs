﻿using System.AddIn;
using System.Drawing;
using System.Windows.Forms;
using RightNow.AddIns.AddInViews;
using RightNow.AddIns.Common;
using System.ServiceModel;
using System.Web.Services.Protocols;
using System.ServiceModel.Channels;

////////////////////////////////////////////////////////////////////////////////
//
// File: Assign_Incident.cs
//
// Comments:
//
// Notes: 
//
// Pre-Conditions: 
//
////////////////////////////////////////////////////////////////////////////////
namespace TEST_CWS_addin
{
    public class Assign_Incident : Panel, IWorkspaceComponent2
    {
        /// <summary>
        /// The current workspace record context.
        /// </summary>
        private IGlobalContext _GlobalContext;
        private IRecordContext _recordContext;
        private AssignButton _button;
        
        // SOAP setup variables
        private RightNowService.RightNowSyncPortClient _client;
        private RightNowService.ClientInfoHeader _clientInfoHeader;
        private string _username = "k_addin";
        private string _password = "1qaz!QAZ";
        private const string _appID = "TEST_CWS_AddIn";

        [ServerConfigProperty(DefaultValue = "k_addin")]
        public string SOAP_Username
        {
            get
            {
                return _username;
            }
            set
            {
                _username = value;
            }
        }

        [ServerConfigProperty(DefaultValue = "1qaz!QAZ")]
        public string SOAP_Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="inDesignMode">Flag which indicates if the control is being drawn on the Workspace Designer. (Use this flag to determine if code should perform any logic on the workspace record)</param>
        /// <param name="RecordContext">The current workspace record context.</param>
        public Assign_Incident(bool inDesignMode, IRecordContext RecordContext, IGlobalContext GlobalContext)
        {
            _GlobalContext = GlobalContext;
            _recordContext = RecordContext;
            _button = new AssignButton();

            this.Dock = DockStyle.Fill;
            this.Controls.Add(_button);

            if (!inDesignMode)
            {
                _button.assignClicked += new AssignButton.buttonHandler(_button_assignClicked);
            }
        }

        void _button_assignClicked()
        {
            //Create an incident object
            RightNowService.Incident incident = new RightNowService.Incident();

            //Create ID object for incident_id
            RightNowService.ID incID = new RightNowService.ID();
            //Get the incident record being worked on
            IIncident _incRecord = _recordContext.GetWorkspaceRecord(WorkspaceRecordType.Incident) as IIncident;
            incID.id = _incRecord.ID;
            incID.idSpecified = true;
            //Set incident ID to ID object
            incident.ID = incID;

            //Create a GroupAccount & set every object
            RightNowService.GroupAccount agent = new RightNowService.GroupAccount();
            agent.Account = new RightNowService.NamedID();
            agent.Account.ID = new RightNowService.ID();
            agent.Account.ID.id = _GlobalContext.AccountId;
            agent.Account.ID.idSpecified = true;
            //Assign the agent to the incident
            incident.AssignedTo = agent;

            //Set the update processiong options
            RightNowService.UpdateProcessingOptions options = new RightNowService.UpdateProcessingOptions();
            options.SuppressExternalEvents = true;
            options.SuppressRules = true;

            //Create the RNObject array
            RightNowService.RNObject[] objects = new RightNowService.RNObject[] {incident};

            // Header
            _clientInfoHeader = new RightNowService.ClientInfoHeader();
            _clientInfoHeader.AppID = _appID;

            //Get URL & create Soap service
            string url = _GlobalContext.InterfaceURL;
            url = url.Replace("http:", "https:");
            url = url.Replace("/php/", "/services/soap");

            EndpointAddress endpoint = new EndpointAddress(url);
            BasicHttpBinding binding = new BasicHttpBinding(BasicHttpSecurityMode.TransportWithMessageCredential);
            binding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;

            _client = new RightNowService.RightNowSyncPortClient(binding, endpoint);
            _client.ClientCredentials.UserName.UserName = _username;
            _client.ClientCredentials.UserName.Password = _password;

            BindingElementCollection elements = _client.Endpoint.Binding.CreateBindingElements();
            elements.Find<SecurityBindingElement>().IncludeTimestamp = false;

            _client.Endpoint.Binding = new CustomBinding(elements);

            //Send the request
            try
            {
                _client.Update(_clientInfoHeader, objects, options);
            }
            catch (FaultException ex)
            {
                MessageBox.Show("Fault Code: "+ex.Code);
                MessageBox.Show(ex.Message);
            }
            catch (SoapException ex)
            {
                MessageBox.Show("Soap Code: "+ex.Code);
                MessageBox.Show(ex.Message);
            }

            MessageBox.Show("The incident has been assigned to you.");
        }

        #region IAddInControl Members

        /// <summary>
        /// Method called by the Add-In framework to retrieve the control.
        /// </summary>
        /// <returns>The control, typically 'this'.</returns>
        public Control GetControl()
        {
            return this;
        }

        #endregion

        #region IWorkspaceComponent2 Members

        /// <summary>
        /// Sets the ReadOnly property of this control.
        /// </summary>
        public bool ReadOnly { get; set; }

        /// <summary>
        /// Method which is called when any Workspace Rule Action is invoked.
        /// </summary>
        /// <param name="ActionName">The name of the Workspace Rule Action that was invoked.</param>
        public void RuleActionInvoked(string ActionName)
        {
        }

        /// <summary>
        /// Method which is called when any Workspace Rule Condition is invoked.
        /// </summary>
        /// <param name="ConditionName">The name of the Workspace Rule Condition that was invoked.</param>
        /// <returns>The result of the condition.</returns>
        public string RuleConditionInvoked(string ConditionName)
        {
            return string.Empty;
        }

        #endregion
    }

    [AddIn("Workspace Factory AddIn", Version = "1.0.0.0")]
    public class WorkspaceAddInFactory : IWorkspaceComponentFactory2
    {
        #region IWorkspaceComponentFactory2 Members
        private IGlobalContext _GlobalContext;

        /// <summary>
        /// Method which is invoked by the AddIn framework when the control is created.
        /// </summary>
        /// <param name="inDesignMode">Flag which indicates if the control is being drawn on the Workspace Designer. (Use this flag to determine if code should perform any logic on the workspace record)</param>
        /// <param name="RecordContext">The current workspace record context.</param>
        /// <returns>The control which implements the IWorkspaceComponent2 interface.</returns>
        public IWorkspaceComponent2 CreateControl(bool inDesignMode, IRecordContext RecordContext)
        {
            return new Assign_Incident(inDesignMode, RecordContext, _GlobalContext);
        }

        #endregion

        #region IFactoryBase Members

        /// <summary>
        /// The 16x16 pixel icon to represent the Add-In in the Ribbon of the Workspace Designer.
        /// </summary>
        public Image Image16
        {
            get { return Properties.Resources.AddIn16; }
        }

        /// <summary>
        /// The text to represent the Add-In in the Ribbon of the Workspace Designer.
        /// </summary>
        public string Text
        {
            get { return "Assign_Incident"; }
        }

        /// <summary>
        /// The tooltip displayed when hovering over the Add-In in the Ribbon of the Workspace Designer.
        /// </summary>
        public string Tooltip
        {
            get { return "Assign_Incident: Assign an incident to yourself."; }
        }

        #endregion

        #region IAddInBase Members

        /// <summary>
        /// Method which is invoked from the Add-In framework and is used to programmatically control whether to load the Add-In.
        /// </summary>
        /// <param name="GlobalContext">The Global Context for the Add-In framework.</param>
        /// <returns>If true the Add-In to be loaded, if false the Add-In will not be loaded.</returns>
        public bool Initialize(IGlobalContext GlobalContext)
        {
            _GlobalContext = GlobalContext;
            return true;
        }

        #endregion
    }
}